# 팀 공통 벤치마크 규칙

테스트셋 sha256: `22a6790882a6af0a4a4cbd784fba4fee62889afb80fcbc0816e3dbdaac8c8713`
점수를 공유할 때 이 값이 같아야 같은 시험지로 본 점수입니다.

## 파일

- `reviews.csv`: 리뷰 본문과 정답. `label` 1 = LLM, 0 = 사람. `text_surface` / `text_nospace` 는 ablation용 텍스트
- `splits.csv`: 실험마다 각 행이 train / val / test 중 어디에 쓰이는지. 빈칸은 그 실험에서 쓰지 않는 행
- `llm_generated_all.csv`: 생성된 LLM 리뷰 전체 (참고용. 점수 공유는 반드시 위 두 파일 기준)
- `dataset.parquet`, `test_freeze.json`: 공통 채점 스크립트용

## 실험

| 실험 | 쓸 텍스트 컬럼 | 내용 |
|---|---|---|
| `main` | `text` | 전체 생성기·프롬프트로 학습/평가 |
| `ablation_surface` | `text_surface` | main과 같은 분할, 구두점·이모지·자모 제거 텍스트 |
| `ablation_nospace` | `text_nospace` | main과 같은 분할, 띄어쓰기까지 제거 |
| `logo_anthropic` | `text` | `anthropic` 계열을 학습에서 빼고, 그 계열 리뷰 전부로 평가 (미학습 생성기) |
| `logo_openai` | `text` | `openai` 계열을 학습에서 빼고, 그 계열 리뷰 전부로 평가 (미학습 생성기) |
| `lopo_A` | `text` | 프롬프트 `A` 를 학습에서 빼고 평가 (미학습 프롬프트) |
| `lopo_C` | `text` | 프롬프트 `C` 를 학습에서 빼고 평가 (미학습 프롬프트) |

필수: `main`, `logo_*` 전부. 권장: `ablation_surface`. 선택: 나머지.

## 규칙

1. 실험마다 `splits.csv` 에서 그 실험 컬럼이 `train` 인 행으로만 학습합니다.
2. 하이퍼파라미터, 에폭, 임베딩 모델 선택은 `val` 로만 합니다. **`test` 정답을 보고 고르면 안 됩니다.**
3. `val` 과 `test` 행 전부에 점수를 매깁니다. 점수는 클수록 LLM다운 쪽이면 아무 값이나 됩니다 (확률, 로짓, 거리 등).
4. 임계값은 직접 정하지 않습니다. 채점 스크립트가 val에서 FPR 1%/5% 임계값을 정해 test에 적용합니다.

## 제출 형식

`predictions/<모델이름>/<실험이름>.csv`, 컬럼은 `id,score` 두 개.

```
id,score
h000123,-2.31
g000456,1.87
```

## 채점

```
python -m beta.score_predictions --model e5base_lr_홍길동 --dir predictions/e5base_lr_홍길동 --dataset benchmark/dataset.parquet
python -m beta.report
```

모델 이름에 본인 이름을 넣어 겹치지 않게 하세요. 각자의 `results/<모델이름>/` 폴더를 한 곳에 모으고 `python -m beta.report` 를 돌리면 전원 점수가 한 보고서에 나옵니다.

## 라이선스

사람 리뷰는 KR3 (https://huggingface.co/datasets/leey4n/KR3, CC BY-NC-SA 4.0)에서 가져와 정규화·필터링했습니다.
이 벤치마크도 같은 **CC BY-NC-SA 4.0** 을 따릅니다: 출처(KR3) 표시, 비상업 용도만, 수정본도 같은 라이선스로 배포.
LLM 리뷰는 연구용으로 생성한 합성 데이터이며 실제 리뷰로 게시하는 데 쓰면 안 됩니다.

## 데이터 구성

| source | test | train | val |
|---|---|---|---|
| claude | 179 | 828 | 175 |
| gpt | 174 | 809 | 173 |
| human | 351 | 1637 | 350 |
